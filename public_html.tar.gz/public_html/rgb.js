 function change_color_width(){
    var r = document.getElementById("r").value;
    var g = document.getElementById("g").value;
    var b = document.getElementById("b").value;
    var border_width = document.getElementById("border_width").value;


    var tag = document.getElementById("paragraph");
    tag.style.borderColor = `rgb(${r},${g},${b})`;
    tag.style.borderWidth = border_width
    tag.style.color  = `rgb(${r},${g},${b})`;
 }
