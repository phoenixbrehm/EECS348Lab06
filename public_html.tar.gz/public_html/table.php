<html>
<body>


<table border="1">
<tbody>
    <tr>
        <?php
        for($i = 0; $i < $_POST["size"]+1; $i++){
            if($i==0){
                echo "<td></td>";  
            }else{
                echo "<td>" . $i . "</td>";
            }
        }?>
    </tr>
    <?php
    $c = 1;
    for ($i = 1; $i <= $_POST["size"]; $i++){
        echo "<tr>";
        echo "<td>" . $c . "</td>";
        $c++;
        for ($j = 1; $j <= $_POST["size"]; $j++){
            echo "<td>" . $i * $j . "</td>";
        }
        echo "</tr>";
    }?>
</tbody>
</table>

</body>
</html>
