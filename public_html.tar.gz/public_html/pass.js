function pass(){
    var pass1 = document.getElementById("pass1").value;
    var pass2 = document.getElementById("pass2").value;
    
    if(pass1.length < 8){
        alert("The Password in field 1 is less than 8 characters!")
    }else if(pass2.length < 8){
        alert("The Password in field 2 is less than 8 characters!")
    }else if(pass1 != pass2){
        alert("The Passwords do not match!")
    }else{
        alert("Passwords Valid")
    }
} 
